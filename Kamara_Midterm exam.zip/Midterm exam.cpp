#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

using namespace std;

const double MinFee = 8.00;
const double AdditionalFee = 2.50;
const double CommercFee = 10.00;
const double MaxCharge = 60.00;

void getNameAndHours(string& Full_Name, double& Number);
bool isCommercial();
double calcCharges(double Number, bool Commercial);

int main() {
    
    ofstream report("report.txt");

   
    report << fixed << showpoint << setprecision(2);

   
    int nameWidth = 20;
    int hoursWidth = 10;
    int chargeWidth = 10;
    int commercialWidth = 12;

    
    report << left << setw(nameWidth) << "Customer"
           << setw(hoursWidth) << "Hours"
           << setw(chargeWidth) << "Charge"
           << setw(commercialWidth) << "Commercial" << endl;

    for (int i = 0; i < 3; i++) {
        string Full_Name;
        double Number;
        bool Commercial;
        double Charge;

        
        getNameAndHours(Full_Name, Number);

      
        Commercial = isCommercial();

        
        Charge = calcCharges(Number, Commercial);

       
        report << left << setw(nameWidth) << Full_Name
               << setw(hoursWidth) << Number
               << setw(chargeWidth) << (Charge > MaxCharge ? MaxCharge : Charge)
               << setw(commercialWidth) << (Commercial ? "Y" : "N") << endl;
    }

   
    report.close();
    cout << "The report has been saved to report.txt" << endl;

    return 0;
}

void getNameAndHours(string& Full_Name, double& Number) {
    cout << "Enter Customer's Name: ";
    getline(cin, Full_Name);
    cout << "Enter Hours Parked: ";
    cin >> Number;
    cin.ignore();
}

bool isCommercial() {
    char response;
    cout << "Is the vehicle commercial? (Y/N): ";
    cin >> response;
    cin.ignore();
    return (response == 'Y' || response == 'y');
}

double calcCharges(double Number, bool Commercial) {
    double Charge = MinFee;
    if (Number > 4) {
        Charge += AdditionalFee * (Number - 4);
    }
    if (Commercial) {
        Charge += CommercFee;
    }
    if (Charge > MaxCharge) {
        Charge = MaxCharge;
    }
    return Charge;
}
